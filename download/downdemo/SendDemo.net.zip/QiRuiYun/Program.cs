﻿using System;
using System.Net;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Threading;
using System.Web;

namespace QiRuiYun
{
    class Program
    {
        private const string BASEURL = "http://api.qirui.com:7891/mt";

        static void Main(string[] args)
        {
            //APIKey(用户名)
            String apiKey    = "xxxxxxxxxx";
            //APISecret(密码)
            String apiSecret = "xxxxxxxxxxxxxxxxxxxx";
            //接受短信的手机号
            String mobile    = "15100000000";
            //短信内容(【签名】+短信内容)，系统提供的测试签名和内容，如需要发送自己的短信内容请在启瑞云平台申请签名和模板
            String message   = "【启瑞云】您的验证码是:5283";

            string template = "?dc=15&un={0}&pw={1}&da={2}&sm={3}&tf=3&rf=2&rd=1";
            string url = BASEURL + string.Format(template, apiKey, apiSecret, mobile, HttpUtility.UrlEncode(message, Encoding.UTF8));
            //Console.WriteLine(url);
            var result = doRequest(url);

            Console.WriteLine(result);
        }

        static private String doRequest(string url)
        {
            string result;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException ex)
            {
                response = (HttpWebResponse)ex.Response;
            }
            using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            {
                result = reader.ReadToEnd();
            }
            return result;
        }

    }
}
